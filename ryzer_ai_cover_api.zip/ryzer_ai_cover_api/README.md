# Ryzer AI Cover — API starter

Bu paket web arayüzünü ve Ryzer API proxy'sini içerir. **Kendi başına AI ses dönüştürme motoru değildir.** Ses dönüşümü için ayrıca erişilebilir bir RVC inference sunucusu ve izinli bir ses modeli gerekir.

## Render ile yayınlama

1. Bu klasördeki dosyaları kendi GitHub deponun kök dizinine yükle.
2. Render hesabında **New → Blueprint** seçip bu depoyu bağla. `render.yaml` servis ayarlarını sağlar. Alternatif olarak **New → Web Service** seç, Docker runtime ile deploy et.
3. Deploy bittikten sonra `https://<servis-adin>.onrender.com` adresini aç.
4. `/api` adresi API durumunu, `/docs` ise API belgelerini gösterir.

## RVC motorunu bağlama

Render servisinin Environment ayarlarında `RVC_API_URL` değerini erişilebilir RVC API adresine ayarla. `http://127.0.0.1:8000` yalnızca RVC aynı makine/container içinde çalışıyorsa örnektir; ayrı bir serviste localhost çalışmaz. RVC motoru erişilebilir değilse cover dönüştürme çalışmayacaktır.

## Yerel başlatma

Python 3.10–3.12 önerilir.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

Windows PowerShell:
```powershell
$env:RVC_API_URL="http://127.0.0.1:8000"
uvicorn app:app --host 0.0.0.0 --port 7860
```

macOS/Linux:
```bash
export RVC_API_URL="http://127.0.0.1:8000"
uvicorn app:app --host 0.0.0.0 --port 7860
```

## Uç noktalar

- `GET /api/v1/health` — RVC motorunun sağlık kontrolünü proxy eder.
- `GET /api/v1/models` — motor üzerindeki modelleri listeler.
- `POST /api/v1/convert` — `audio`, `model_id`, `pitch`, `f0_method`, `index_rate`, `output_format` alanlarıyla dönüşüm yapar.

## Ücretsiz kullanım hakkında

Render ücretsiz web hizmetleri test için uygundur fakat 15 dakika trafik olmadığında uykuya geçer ve yeniden açılması yaklaşık bir dakika sürebilir. Ücretsiz hosting, GPU gerektiren RVC inference hizmetini otomatik olarak sağlamaz. GPU/AI motorunun ücretsiz ve sürekli açık olacağı garanti edilemez.

## Güvenlik

- Varsayılan maksimum yükleme boyutu 20 MB'dır (`MAX_UPLOAD_MB`).
- İnternete açmadan önce HTTPS, erişim kontrolü, hız sınırı ve kötüye kullanım koruması ekle.
- Yalnızca kullanma iznin olan ses modellerini kullan; ses taklidi ve yayınlama için izinleri ve platform kurallarını kontrol et.
