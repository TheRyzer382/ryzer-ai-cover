import os
from pathlib import Path

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, Response
from fastapi.staticfiles import StaticFiles

RVC_API_URL = os.getenv("RVC_API_URL", "http://127.0.0.1:8000").rstrip("/")
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "20")) * 1024 * 1024
INDEX_HTML = Path(__file__).parent / "index.html"

app = FastAPI(
    title="Ryzer AI Cover API",
    description="Ryzer AI Cover frontend API proxy for a separately running RVC inference server.",
    version="1.0.0",
)

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def home():
    return HTMLResponse(INDEX_HTML.read_text(encoding="utf-8"))

async def upstream(method: str, path: str, **kwargs):
    timeout = httpx.Timeout(600.0, connect=10.0)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            result = await client.request(method, f"{RVC_API_URL}{path}", **kwargs)
    except httpx.RequestError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"RVC motoruna bağlanılamadı. RVC_API_URL ayarını ve motorun çalıştığını kontrol et. ({type(exc).__name__})",
        ) from exc
    if result.status_code >= 400:
        detail = result.text[:1000] if result.text else f"RVC upstream HTTP {result.status_code}"
        raise HTTPException(status_code=result.status_code, detail=detail)
    return result

@app.get("/api/v1/health")
async def health():
    result = await upstream("GET", "/api/v1/health")
    try:
        return result.json()
    except ValueError:
        return {"status": "ok", "upstream": result.text[:500]}

@app.get("/api/v1/models")
async def models():
    result = await upstream("GET", "/api/v1/models")
    try:
        return result.json()
    except ValueError as exc:
        raise HTTPException(status_code=502, detail="RVC motoru geçersiz model listesi döndürdü.") from exc

@app.post("/api/v1/convert")
async def convert(
    audio: UploadFile = File(...),
    model_id: str = Form(...),
    pitch: int = Form(0),
    f0_method: str = Form("rmvpe"),
    index_rate: float = Form(0.5),
    output_format: str = Form("wav"),
):
    if not model_id.strip():
        raise HTTPException(status_code=400, detail="model_id gerekli.")
    if not -24 <= pitch <= 24:
        raise HTTPException(status_code=400, detail="pitch -24 ile +24 arasında olmalı.")
    if not 0.0 <= index_rate <= 1.0:
        raise HTTPException(status_code=400, detail="index_rate 0 ile 1 arasında olmalı.")
    if output_format not in {"wav", "mp3", "flac", "ogg"}:
        raise HTTPException(status_code=400, detail="Desteklenmeyen çıktı formatı.")
    data = await audio.read(MAX_UPLOAD_BYTES + 1)
    if not data:
        raise HTTPException(status_code=400, detail="Ses dosyası boş.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail=f"Dosya boyutu sınırı {MAX_UPLOAD_BYTES // (1024*1024)} MB.")
    filename = Path(audio.filename or "audio.wav").name
    files = {"audio": (filename, data, audio.content_type or "application/octet-stream")}
    form = {
        "model_id": model_id.strip(),
        "pitch": str(pitch),
        "f0_method": f0_method,
        "index_rate": str(index_rate),
        "output_format": output_format,
    }
    result = await upstream("POST", "/api/v1/convert", files=files, data=form)
    content_type = result.headers.get("content-type", "audio/wav")
    # The browser needs the generated audio bytes, not the upstream JSON wrapper.
    if "application/json" in content_type:
        raise HTTPException(status_code=502, detail=result.text[:1000])
    return Response(
        content=result.content,
        media_type=content_type,
        headers={"Content-Disposition": f'attachment; filename="ryzer-ai-cover.{output_format}"'},
    )

@app.get("/api")
async def api_root():
    return {
        "name": "Ryzer AI Cover API",
        "status": "running",
        "docs": "/docs",
        "routes": ["/api/v1/health", "/api/v1/models", "/api/v1/convert"],
        "rvc_upstream_configured": bool(RVC_API_URL),
    }
